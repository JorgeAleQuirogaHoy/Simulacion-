package practicesimulation01;
import java.util.Scanner;
import java.util.Random;
public class PracticeSimulation01 {
    public static void main(String[] args) {
        Scanner leer = new Scanner (System.in);
        Random NumRandom =  new Random ();
        System.out.print("Ingrese la cantidad de numeros que se generaran de forma aleatoria: ");
        int Random = leer.nextInt();
        System.out.println("Ingrese el numero minimo de numeros que se generaran: ");
        int Min = leer.nextInt();
        System.out.println("Ingrese el numero maximo de numeros que se generaran: ");
        int Max = leer.nextInt();
        int suma = 0;
        for (int i = 0; i < Random; i++) {
            int numero = NumRandom.nextInt((Max - Min) + 1) + Min;
            suma += numero;
        }
        double promedio = (double) suma / Random;
        System.out.println("El promedio de los números generados es: " + promedio);
    }
    
}
